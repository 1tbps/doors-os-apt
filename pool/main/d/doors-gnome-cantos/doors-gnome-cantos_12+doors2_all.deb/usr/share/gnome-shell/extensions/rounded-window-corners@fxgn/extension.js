import {
  Extension,
  InjectionManager
} from "resource:///org/gnome/shell/extensions/extension.js";
import { layoutManager } from "resource:///org/gnome/shell/ui/main.js";
import { WindowPreview } from "resource:///org/gnome/shell/ui/windowPreview.js";
import { WorkspaceAnimationController } from "resource:///org/gnome/shell/ui/workspaceAnimation.js";
import { disableEffect, enableEffect } from "./manager/event_manager.js";
import { addShadowInOverview } from "./patch/add_shadow_in_overview.js";
import {
  addShadowsInWorkspaceSwitch,
  removeShadowsAfterWorkspaceSwitch
} from "./patch/workspace_switch.js";
import {
  disableBackgroundMenuItem,
  enableBackgroundMenuItem
} from "./utils/background_menu.js";
import { logDebug } from "./utils/log.js";
import { getPref, initPrefs, prefs, uninitPrefs } from "./utils/settings.js";
import { WindowPicker } from "./window_picker/service.js";
class RoundedWindowCornersReborn extends Extension {
  // The extension works by overriding (monkey patching) the code of GNOME
  // Shell's internal methods. InjectionManager is a convenience class that
  // stores references to the original methods and allows to easily restore
  // them when the extension is disabled.
  #injectionManager = null;
  #windowPicker = null;
  #layoutManagerStartupConnection = null;
  #workspaceSwitchConnections = null;
  enable() {
    initPrefs(this.getSettings());
    this.#injectionManager = new InjectionManager();
    this.#windowPicker = new WindowPicker();
    this.#windowPicker.export();
    if (layoutManager._startingUp) {
      this.#layoutManagerStartupConnection = layoutManager.connect(
        "startup-complete",
        () => {
          enableEffect();
          if (getPref("enable-preferences-entry")) {
            enableBackgroundMenuItem();
          }
          layoutManager.disconnect(
            // Since this happens inside of the connection, there
            // is no way for this to be null.
            // biome-ignore lint/style/noNonNullAssertion:
            this.#layoutManagerStartupConnection
          );
        }
      );
    } else {
      enableEffect();
      if (getPref("enable-preferences-entry")) {
        enableBackgroundMenuItem();
      }
    }
    const self = this;
    this.#injectionManager.overrideMethod(
      WindowPreview.prototype,
      "_addWindow",
      (addWindow) => function(window) {
        addWindow.call(this, window);
        addShadowInOverview(window, this);
      }
    );
    this.#injectionManager.overrideMethod(
      WorkspaceAnimationController.prototype,
      "_prepareWorkspaceSwitch",
      (prepareWorkspaceSwitch) => function(workspaceIndices) {
        prepareWorkspaceSwitch.call(this, workspaceIndices);
        self.#workspaceSwitchConnections = addShadowsInWorkspaceSwitch(this);
      }
    );
    this.#injectionManager.overrideMethod(
      WorkspaceAnimationController.prototype,
      "_finishWorkspaceSwitch",
      (finishWorkspaceSwitch) => function(switchData) {
        removeShadowsAfterWorkspaceSwitch(this);
        finishWorkspaceSwitch.call(this, switchData);
      }
    );
    prefs.connect("changed", (_, key) => {
      if (key === "enable-preferences-entry") {
        getPref("enable-preferences-entry") ? enableBackgroundMenuItem() : disableBackgroundMenuItem();
      }
    });
    logDebug("Enabled");
  }
  disable() {
    this.#injectionManager?.clear();
    this.#injectionManager = null;
    disableBackgroundMenuItem();
    this.#windowPicker?.unexport();
    disableEffect();
    this.#windowPicker = null;
    if (this.#layoutManagerStartupConnection !== null) {
      layoutManager.disconnect(this.#layoutManagerStartupConnection);
      this.#layoutManagerStartupConnection = null;
    }
    for (const connection of this.#workspaceSwitchConnections ?? []) {
      connection.object.disconnect(connection.id);
    }
    logDebug("Disabled");
    uninitPrefs();
  }
}
export {
  RoundedWindowCornersReborn as default
};

import Clutter from "gi://Clutter";
import GLib from "gi://GLib";
import GObject from "gi://GObject";
import St from "gi://St";
import { ClipShadowEffect } from "../effect/clip_shadow_effect.js";
import { RoundedCornersEffect } from "../effect/rounded_corners_effect.js";
import {
  CLIP_SHADOW_EFFECT,
  ROUNDED_CORNERS_EFFECT
} from "../utils/constants.js";
import { logDebug } from "../utils/log.js";
import { getPref } from "../utils/settings.js";
import {
  computeBounds,
  computeShadowActorOffset,
  computeWindowContentsOffset,
  getRoundedCornersCfg,
  getRoundedCornersEffect,
  shouldEnableEffect,
  unwrapActor,
  updateShadowActorStyle,
  windowScaleFactor
} from "./utils.js";
function onAddEffect(actor) {
  logDebug(`opened: ${actor?.metaWindow.title}: ${actor}`);
  const win = actor.metaWindow;
  if (!shouldEnableEffect(win)) {
    logDebug(`Skipping ${win.title}`);
    return;
  }
  unwrapActor(actor)?.add_effect_with_name(
    ROUNDED_CORNERS_EFFECT,
    new RoundedCornersEffect()
  );
  const shadow = createShadow(actor);
  for (const prop of [
    "pivot-point",
    "translation-x",
    "translation-y",
    "scale-x",
    "scale-y",
    "visible"
  ]) {
    actor.bind_property(
      prop,
      shadow,
      prop,
      GObject.BindingFlags.SYNC_CREATE
    );
  }
  actor.rwcCustomData = {
    shadow,
    unminimizedTimeoutId: 0
  };
  refreshRoundedCorners(actor);
  refreshShadow(actor);
}
function onRemoveEffect(actor) {
  const name = ROUNDED_CORNERS_EFFECT;
  unwrapActor(actor)?.remove_effect_by_name(name);
  const shadow = actor.rwcCustomData?.shadow;
  if (shadow) {
    global.windowGroup.remove_child(shadow);
    shadow.clear_effects();
    shadow.destroy();
  }
  const timeoutId = actor.rwcCustomData?.unminimizedTimeoutId;
  if (timeoutId) {
    GLib.source_remove(timeoutId);
  }
  delete actor.rwcCustomData;
}
function onMinimize(actor) {
  const magicLampEffect = actor.get_effect("minimize-magic-lamp-effect");
  const shadow = actor.rwcCustomData?.shadow;
  const roundedCornersEffect = getRoundedCornersEffect(actor);
  if (magicLampEffect && shadow && roundedCornersEffect) {
    logDebug("Minimizing with magic lamp effect");
    shadow.visible = false;
    roundedCornersEffect.enabled = false;
  }
}
function onUnminimize(actor) {
  const magicLampEffect = actor.get_effect("unminimize-magic-lamp-effect");
  const shadow = actor.rwcCustomData?.shadow;
  const roundedCornersEffect = getRoundedCornersEffect(actor);
  if (magicLampEffect && shadow && roundedCornersEffect) {
    shadow.visible = false;
    const timer = magicLampEffect.timerId;
    const id = timer.connect("new-frame", (source) => {
      if (source.get_progress() > 0.98) {
        logDebug("Unminimizing with magic lamp effect");
        shadow.visible = true;
        roundedCornersEffect.enabled = true;
        source.disconnect(id);
      }
    });
    return;
  }
}
function onRestacked() {
  for (const actor of global.get_window_actors()) {
    const shadow = actor.rwcCustomData?.shadow;
    if (!(actor.visible && shadow)) {
      continue;
    }
    global.windowGroup.set_child_below_sibling(shadow, actor);
  }
}
const onSizeChanged = refreshRoundedCorners;
function onFocusChanged(actor) {
  refreshShadow(actor);
  refreshRoundedCorners(actor);
}
function onSettingsChanged(key) {
  switch (key) {
    case "skip-libadwaita-app":
    case "skip-libhandy-app":
    case "blacklist":
      refreshEffectState();
      break;
    case "focused-shadow":
    case "unfocused-shadow":
      refreshAllShadows();
      break;
    case "global-rounded-corner-settings":
    case "custom-rounded-corner-settings":
    case "border-width":
    case "tweak-kitty-terminal":
      refreshAllRoundedCorners();
      break;
    default:
  }
}
function createShadow(actor) {
  const shadow = new St.Bin({
    name: "Shadow Actor",
    child: new St.Bin({
      xExpand: true,
      yExpand: true
    })
  });
  shadow.firstChild.add_style_class_name("shadow");
  refreshShadow(actor);
  shadow.add_effect_with_name(CLIP_SHADOW_EFFECT, new ClipShadowEffect());
  global.windowGroup.insert_child_below(shadow, actor);
  for (let i = 0; i < 4; i++) {
    const constraint = new Clutter.BindConstraint({
      source: actor,
      coordinate: i,
      offset: 0
    });
    shadow.add_constraint(constraint);
  }
  return shadow;
}
function refreshEffectState() {
  for (const actor of global.get_window_actors()) {
    const shouldHaveEffect = shouldEnableEffect(actor.metaWindow);
    const hasEffect = getRoundedCornersEffect(actor) != null;
    if (shouldHaveEffect && !hasEffect) {
      onAddEffect(actor);
      refreshRoundedCorners(actor);
      return;
    }
    if (!shouldHaveEffect && hasEffect) {
      onRemoveEffect(actor);
      return;
    }
  }
}
function refreshShadow(actor) {
  const win = actor.metaWindow;
  const shadow = actor.rwcCustomData?.shadow;
  if (!shadow) {
    return;
  }
  const shadowSettings = win.appears_focused ? getPref("focused-shadow") : getPref("unfocused-shadow");
  const { borderRadius, padding } = getRoundedCornersCfg(win);
  updateShadowActorStyle(win, shadow, borderRadius, shadowSettings, padding);
}
function refreshAllShadows() {
  for (const actor of global.get_window_actors()) {
    refreshShadow(actor);
  }
}
function refreshRoundedCorners(actor) {
  const win = actor.metaWindow;
  const windowInfo = actor.rwcCustomData;
  const effect = getRoundedCornersEffect(actor);
  const shouldHaveEffect = shouldEnableEffect(win);
  if (!(effect && windowInfo)) {
    if (shouldHaveEffect) {
      logDebug(`Adding previously missing effect to ${win.title}`);
      onAddEffect(actor);
    }
    return;
  }
  const cfg = getRoundedCornersCfg(win);
  if (effect.enabled !== shouldHaveEffect) {
    effect.enabled = shouldHaveEffect;
    refreshShadow(actor);
  }
  const windowContentOffset = computeWindowContentsOffset(win);
  effect.updateUniforms(
    windowScaleFactor(win),
    cfg,
    computeBounds(actor, windowContentOffset)
  );
  const shadow = windowInfo.shadow;
  const offsets = computeShadowActorOffset(actor, windowContentOffset);
  const constraints = shadow.get_constraints();
  constraints.forEach((constraint, i) => {
    if (constraint instanceof Clutter.BindConstraint) {
      constraint.offset = offsets[i];
    }
  });
}
function refreshAllRoundedCorners() {
  for (const actor of global.get_window_actors()) {
    refreshRoundedCorners(actor);
  }
  refreshAllShadows();
}
export {
  onAddEffect,
  onFocusChanged,
  onMinimize,
  onRemoveEffect,
  onRestacked,
  onSettingsChanged,
  onSizeChanged,
  onUnminimize
};

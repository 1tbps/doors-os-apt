import { logDebug } from "../utils/log.js";
import { prefs } from "../utils/settings.js";
import * as handlers from "./event_handlers.js";
function enableEffect() {
  connect(
    prefs,
    "changed",
    (_, key) => handlers.onSettingsChanged(key)
  );
  const wm = global.windowManager;
  const windowActors = global.get_window_actors();
  logDebug(`Initial window count: ${windowActors.length}`);
  for (const actor of windowActors) {
    applyEffectTo(actor);
  }
  connect(
    global.display,
    "window-created",
    (_, win) => {
      const actor = win.get_compositor_private();
      if (win?.get_wm_class_instance() == null) {
        const notifyId = win.connect("notify::wm-class", () => {
          applyEffectTo(actor);
          win.disconnect(notifyId);
        });
      } else {
        applyEffectTo(actor);
      }
    }
  );
  connect(
    wm,
    "minimize",
    (_, actor) => handlers.onMinimize(actor)
  );
  connect(
    wm,
    "unminimize",
    (_, actor) => handlers.onUnminimize(actor)
  );
  connect(
    wm,
    "destroy",
    (_, actor) => removeEffectFrom(actor)
  );
  connect(global.display, "restacked", handlers.onRestacked);
}
function disableEffect() {
  for (const actor of global.get_window_actors()) {
    removeEffectFrom(actor);
  }
  disconnectAll();
}
const connections = [];
function connect(object, signal, callback) {
  connections.push({
    object,
    id: object.connect(signal, callback)
  });
}
function disconnectAll(object) {
  for (const connection of connections) {
    if (object === void 0 || connection.object === object) {
      connection.object.disconnect(connection.id);
    }
  }
}
function applyEffectTo(actor) {
  if (!actor.firstChild) {
    const id = actor.connect("notify::first-child", () => {
      applyEffectTo(actor);
      actor.disconnect(id);
    });
    return;
  }
  const texture = actor.get_texture();
  if (!texture) {
    return;
  }
  connect(actor, "notify::size", () => handlers.onSizeChanged(actor));
  connect(texture, "size-changed", () => {
    handlers.onSizeChanged(actor);
  });
  connect(
    actor.metaWindow,
    "notify::appears-focused",
    () => handlers.onFocusChanged(actor)
  );
  connect(actor.metaWindow, "workspace-changed", () => {
    handlers.onFocusChanged(actor);
  });
  handlers.onAddEffect(actor);
}
function removeEffectFrom(actor) {
  disconnectAll(actor);
  disconnectAll(actor.metaWindow);
  handlers.onRemoveEffect(actor);
}
export {
  disableEffect,
  enableEffect
};

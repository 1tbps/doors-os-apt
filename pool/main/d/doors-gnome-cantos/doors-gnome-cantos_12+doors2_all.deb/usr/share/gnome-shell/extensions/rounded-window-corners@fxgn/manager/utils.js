import Gio from "gi://Gio";
import Meta from "gi://Meta";
import St from "gi://St";
import { boxShadowCss } from "../utils/box_shadow.js";
import {
  APP_SHADOWS,
  ROUNDED_CORNERS_EFFECT,
  SHADOW_PADDING
} from "../utils/constants.js";
import { readFile } from "../utils/file.js";
import { logDebug } from "../utils/log.js";
import { getPref } from "../utils/settings.js";
function unwrapActor(actor) {
  const type = actor.metaWindow.get_client_type();
  return type === Meta.WindowClientType.X11 ? actor.get_first_child() : actor;
}
function getRoundedCornersCfg(win) {
  const globalCfg = getPref("global-rounded-corner-settings");
  const customCfgList = getPref("custom-rounded-corner-settings");
  const wmClass = win.get_wm_class_instance();
  if (wmClass == null || !customCfgList[wmClass] || !customCfgList[wmClass].enabled) {
    return globalCfg;
  }
  return customCfgList[wmClass];
}
function getRoundedCornersEffect(actor) {
  const win = actor.metaWindow;
  const name = ROUNDED_CORNERS_EFFECT;
  return win.get_client_type() === Meta.WindowClientType.X11 ? actor.firstChild.get_effect(name) : actor.get_effect(name);
}
function windowScaleFactor(win) {
  const features = Gio.Settings.new("org.gnome.mutter").get_strv(
    "experimental-features"
  );
  if (Meta.is_wayland_compositor() && features.includes("scale-monitor-framebuffer")) {
    return 1;
  }
  const monitorIndex = win.get_monitor();
  return global.display.get_monitor_scale(monitorIndex);
}
function computeBounds(actor, [x, y, width, height]) {
  const bounds = {
    x1: x + 1,
    y1: y + 1,
    x2: x + actor.width + width,
    y2: y + actor.height + height
  };
  if (getPref("tweak-kitty-terminal")) {
    if (actor.metaWindow.get_client_type() === Meta.WindowClientType.WAYLAND && actor.metaWindow.get_wm_class_instance() === "kitty") {
      const [x1, y1, x2, y2] = APP_SHADOWS.kitty;
      const scale = windowScaleFactor(actor.metaWindow);
      bounds.x1 += x1 * scale;
      bounds.y1 += y1 * scale;
      bounds.x2 -= x2 * scale;
      bounds.y2 -= y2 * scale;
    }
  }
  return bounds;
}
function computeWindowContentsOffset(window) {
  const bufferRect = window.get_buffer_rect();
  const frameRect = window.get_frame_rect();
  return [
    frameRect.x - bufferRect.x,
    frameRect.y - bufferRect.y,
    frameRect.width - bufferRect.width,
    frameRect.height - bufferRect.height
  ];
}
function computeShadowActorOffset(actor, [offsetX, offsetY, offsetWidth, offsetHeight]) {
  const win = actor.metaWindow;
  const shadowPadding = SHADOW_PADDING * windowScaleFactor(win);
  return [
    offsetX - shadowPadding,
    offsetY - shadowPadding,
    2 * shadowPadding + offsetWidth,
    2 * shadowPadding + offsetHeight
  ];
}
function updateShadowActorStyle(win, actor, borderRadius = getPref("global-rounded-corner-settings").borderRadius, shadow = getPref("focused-shadow"), padding = getPref("global-rounded-corner-settings").padding) {
  const { left, right, top, bottom } = padding;
  let adjustedBorderRadius = borderRadius;
  if (getPref("global-rounded-corner-settings") !== null) {
    adjustedBorderRadius *= 1 + getPref("global-rounded-corner-settings").smoothing;
  }
  const originalScale = St.ThemeContext.get_for_stage(
    global.stage
  ).scaleFactor;
  const scale = windowScaleFactor(win) / originalScale;
  actor.style = `padding: ${SHADOW_PADDING * scale}px;`;
  const child = actor.firstChild;
  child.style = win.maximizedHorizontally || win.maximizedVertically || win.fullscreen ? "opacity: 0;" : `background: white;
               border-radius: ${adjustedBorderRadius * scale}px;
               ${boxShadowCss(shadow, scale)};
               margin: ${top * scale}px
                       ${right * scale}px
                       ${bottom * scale}px
                       ${left * scale}px;`;
  child.queue_redraw();
}
function shouldEnableEffect(win) {
  if (win.gtkApplicationId === "com.rastersoft.ding") {
    return false;
  }
  const wmClass = win.get_wm_class_instance();
  if (wmClass == null) {
    logDebug(`Warning: wm_class_instance of ${win}: ${win.title} is null`);
    return false;
  }
  if (getPref("blacklist").includes(wmClass)) {
    return false;
  }
  if (win.windowType !== Meta.WindowType.NORMAL && win.windowType !== Meta.WindowType.DIALOG && win.windowType !== Meta.WindowType.MODAL_DIALOG) {
    return false;
  }
  const appType = win._appType ?? getAppType(win);
  win._appType = appType;
  logDebug(`Check Type of window:${win.title} => ${appType}`);
  if (getPref("skip-libadwaita-app") && appType === "LibAdwaita") {
    return false;
  }
  if (getPref("skip-libhandy-app") && appType === "LibHandy") {
    return false;
  }
  const maximized = win.maximizedHorizontally || win.maximizedVertically;
  const fullscreen = win.fullscreen;
  const cfg = getRoundedCornersCfg(win);
  return !(maximized || fullscreen) || maximized && cfg.keepRoundedCorners.maximized || fullscreen && cfg.keepRoundedCorners.fullscreen;
}
function getAppType(win) {
  try {
    const contents = readFile(`/proc/${win.get_pid()}/maps`);
    if (contents.includes("libhandy-1.so")) {
      return "LibHandy";
    }
    if (contents.includes("libadwaita-1.so")) {
      return "LibAdwaita";
    }
    return "Other";
  } catch (e) {
    logError(e);
    return "Other";
  }
}
export {
  computeBounds,
  computeShadowActorOffset,
  computeWindowContentsOffset,
  getRoundedCornersCfg,
  getRoundedCornersEffect,
  shouldEnableEffect,
  unwrapActor,
  updateShadowActorStyle,
  windowScaleFactor
};

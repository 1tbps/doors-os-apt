import Clutter from "gi://Clutter";
import GObject from "gi://GObject";
import Graphene from "gi://Graphene";
import { overview } from "resource:///org/gnome/shell/ui/main.js";
import { LinearFilterEffect } from "../effect/linear_filter_effect.js";
import { shouldEnableEffect, windowScaleFactor } from "../manager/utils.js";
import { OVERVIEW_SHADOW_ACTOR, SHADOW_PADDING } from "../utils/constants.js";
import { logDebug } from "../utils/log.js";
function addShadowInOverview(window, self) {
  const stack = new Error().stack?.trim();
  if (stack === void 0 || stack.indexOf("_updateAttachedDialogs") !== -1 || stack.indexOf("addDialog") !== -1) {
    return;
  }
  const hasRoundedCorners = shouldEnableEffect(window);
  const windowActor = window.get_compositor_private();
  const shadow = windowActor.rwcCustomData?.shadow;
  if (!(hasRoundedCorners && shadow)) {
    return;
  }
  logDebug(`Adding shadow for ${window.title} in overview`);
  const windowContainer = self.windowContainer;
  let firstChild = windowContainer.firstChild;
  firstChild?.add_effect(new LinearFilterEffect());
  const shadowActorClone = new OverviewShadowActorClone(shadow, self);
  windowContainer.bind_property("scale-x", shadowActorClone, "scale-x", 1);
  windowContainer.bind_property("scale-y", shadowActorClone, "scale-y", 1);
  self.insert_child_below(shadowActorClone, windowContainer);
  const connection = self.connect("destroy", () => {
    shadowActorClone.destroy();
    firstChild?.clear_effects();
    firstChild = null;
    self.disconnect(connection);
  });
}
const OverviewShadowActorClone = GObject.registerClass(
  {},
  class extends Clutter.Clone {
    windowPreview;
    /**
     * Create the clone of the shadow actor.
     * @param source the shadow actor to clone.
     * @param windowPreview the window preview that the clone is applied to.
     */
    constructor(source, windowPreview) {
      super({
        source,
        // the source shadow actor shown in desktop
        name: OVERVIEW_SHADOW_ACTOR,
        pivotPoint: new Graphene.Point({ x: 0.5, y: 0.5 })
      });
      this.windowPreview = windowPreview;
    }
    /**
     * Recompute the position and size of shadow in overview
     * This virtual function will be called when we:
     * - entering/closing overview
     * - dragging window
     * - position and size of window preview in overview changed
     * @param box The bound box of shadow actor
     */
    vfunc_allocate(box) {
      const leavingOverview = overview._overview.controls._workspacesDisplay._leavingOverview;
      const windowContainerBox = leavingOverview ? this.windowPreview.windowContainer.get_allocation_box() : this.windowPreview.get_allocation_box();
      const metaWindow = this.windowPreview._windowActor.get_meta_window();
      if (!metaWindow) {
        return;
      }
      const containerScaleFactor = windowContainerBox.get_width() / metaWindow.get_frame_rect().width;
      const paddings = SHADOW_PADDING * containerScaleFactor * windowScaleFactor(metaWindow);
      box.set_origin(-paddings, -paddings);
      box.set_size(
        windowContainerBox.get_width() + 2 * paddings,
        windowContainerBox.get_height() + 2 * paddings
      );
      super.vfunc_allocate(box);
    }
  }
);
export {
  addShadowInOverview
};

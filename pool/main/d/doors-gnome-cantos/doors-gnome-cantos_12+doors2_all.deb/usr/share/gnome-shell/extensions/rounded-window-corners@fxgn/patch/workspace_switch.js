import Clutter from "gi://Clutter";
import { getRoundedCornersEffect, windowScaleFactor } from "../manager/utils.js";
import { SHADOW_PADDING } from "../utils/constants.js";
function addShadowsInWorkspaceSwitch(self) {
  const connections = [];
  for (const monitor of self._switchData.monitors) {
    for (const workspace of monitor._workspaceGroups) {
      const windowRecords = workspace._windowRecords;
      const restackedConnection = global.display.connect(
        "restacked",
        () => {
          for (const { clone } of windowRecords) {
            const shadow = clone.shadowClone;
            if (shadow) {
              workspace.set_child_below_sibling(shadow, clone);
            }
          }
        }
      );
      const destroyConnection = workspace.connect("destroy", () => {
        global.display.disconnect(restackedConnection);
        workspace.disconnect(destroyConnection);
      });
      connections.push({ object: global.display, id: restackedConnection });
      connections.push({ object: workspace, id: destroyConnection });
      for (const { windowActor: actor, clone } of windowRecords) {
        const win = actor.metaWindow;
        const shadow = actor.rwcCustomData?.shadow;
        const enabled = getRoundedCornersEffect(actor)?.enabled;
        if (!(shadow && enabled)) {
          continue;
        }
        const shadowClone = new Clutter.Clone({
          source: shadow
        });
        const paddings = SHADOW_PADDING * windowScaleFactor(win);
        const frameRect = win.get_frame_rect();
        shadowClone.width = frameRect.width + paddings * 2;
        shadowClone.height = frameRect.height + paddings * 2;
        shadowClone.x = clone.x + frameRect.x - actor.x - paddings;
        shadowClone.y = clone.y + frameRect.y - actor.y - paddings;
        const notifyId = clone.connect("notify::translation-z", () => {
          shadowClone.translationZ = clone.translationZ - 0.05;
        });
        const destroyConnection2 = clone.connect("destroy", () => {
          clone.disconnect(notifyId);
          clone.disconnect(destroyConnection2);
        });
        connections.push({ object: clone, id: notifyId });
        connections.push({ object: clone, id: destroyConnection2 });
        clone.shadowClone = shadowClone;
        clone.bind_property("visible", shadowClone, "visible", 0);
        workspace.insert_child_below(shadowClone, clone);
      }
    }
  }
  return connections;
}
function removeShadowsAfterWorkspaceSwitch(self) {
  for (const monitor of self._switchData.monitors) {
    for (const workspace of monitor._workspaceGroups) {
      for (const { clone } of workspace._windowRecords) {
        clone.shadowClone?.destroy();
        delete clone.shadowClone;
      }
    }
  }
}
export {
  addShadowsInWorkspaceSwitch,
  removeShadowsAfterWorkspaceSwitch
};

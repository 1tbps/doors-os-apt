import { BlacklistPage } from "../preferences/pages/blacklist.js";
import { CustomPage } from "../preferences/pages/custom.js";
import { GeneralPage } from "../preferences/pages/general.js";
const prefsTabs = [
  GeneralPage,
  BlacklistPage,
  CustomPage
];
export {
  prefsTabs
};

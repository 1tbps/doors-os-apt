import Adw from "gi://Adw";
import GLib from "gi://GLib";
import GObject from "gi://GObject";
import Gdk from "gi://Gdk";
import { gettext as _ } from "resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js";
import { getPref, setPref } from "../../utils/settings.js";
import {
  CustomSettingsRow,
  CustomSettingsRowClass
} from "../widgets/custom_settings_row.js";
const CustomPage = GObject.registerClass(
  {
    Template: GLib.uri_resolve_relative(
      import.meta.url,
      "custom.ui",
      GLib.UriFlags.NONE
    ),
    GTypeName: "PrefsCustom",
    InternalChildren: ["customGroup"]
  },
  class extends Adw.PreferencesPage {
    #customWindowSettings = getPref("custom-rounded-corner-settings");
    constructor() {
      super();
      for (const wmClass in this.#customWindowSettings) {
        this.addWindow(void 0, wmClass);
      }
    }
    /**
     * Add a new custom settings row for a window.
     * @param wmClass - The WM_CLASS of the window.
     */
    addWindow(_2, wmClass) {
      const callbacks = {
        onDelete: (row2) => this.#deleteWindowConfig(row2),
        onWindowChange: (row2, oldTitle, newTitle) => this.#changeWindow(row2, oldTitle, newTitle)
      };
      const row = new CustomSettingsRow(callbacks);
      if (wmClass) {
        this.#bindRowSettings(row, wmClass);
      }
      row.set_subtitle(wmClass ?? "");
      this._customGroup.add(row);
    }
    /**
     * Delete custom overrides for a window.
     * @param row - The row to delete.
     */
    #deleteWindowConfig(row) {
      delete this.#customWindowSettings[row.subtitle];
      setPref(
        "custom-rounded-corner-settings",
        this.#customWindowSettings
      );
      this._customGroup.remove(row);
    }
    /**
     * Change the window that the override is applied to.
     * @param row - The row with the override to change.
     * @param oldWmClass - Current WM_CLASS of the override.
     * @param newWmClass - New WM_CLASS of the override.
     * @returns Whether the override was changed successfully.
     */
    #changeWindow(row, oldWmClass, newWmClass) {
      if (this.#customWindowSettings[newWmClass] !== void 0) {
        const win = this.root;
        win.add_toast(
          new Adw.Toast({
            title: _(
              `Can't add ${newWmClass} to the list, because it already there`
            )
          })
        );
        return false;
      }
      if (oldWmClass === "") {
        this.#customWindowSettings[newWmClass] = getPref(
          "global-rounded-corner-settings"
        );
      } else {
        const cfg = this.#customWindowSettings[oldWmClass];
        delete this.#customWindowSettings[oldWmClass];
        this.#customWindowSettings[newWmClass] = cfg;
      }
      this.#bindRowSettings(row, newWmClass);
      setPref(
        "custom-rounded-corner-settings",
        this.#customWindowSettings
      );
      return true;
    }
    /**
     * Bind widgets of the override row to the respective settings.
     * @param row - The row to bind.
     * @param wmClass - WM_CLASS of the window that the override is applied to.
     */
    #bindRowSettings(row, wmClass) {
      if (!(row instanceof CustomSettingsRowClass)) {
        return;
      }
      const r = row;
      r.connect("notify::subtitle", (row2) => {
        row2.checkState();
      });
      r.enabledRow.set_active(
        this.#customWindowSettings[wmClass].enabled
      );
      r.enabledRow.connect("notify::active", (row2) => {
        r.checkState();
        this.#customWindowSettings[wmClass].enabled = row2.get_active();
        setPref(
          "custom-rounded-corner-settings",
          this.#customWindowSettings
        );
      });
      const color = new Gdk.RGBA();
      [color.red, color.green, color.blue, color.alpha] = this.#customWindowSettings[wmClass].borderColor;
      r.borderColorButton.set_rgba(color);
      r.borderColorButton.connect(
        "notify::rgba",
        (_button) => {
          const color2 = r.borderColorButton.get_rgba();
          this.#customWindowSettings[wmClass].borderColor = [
            color2.red,
            color2.green,
            color2.blue,
            color2.alpha
          ];
          setPref(
            "custom-rounded-corner-settings",
            this.#customWindowSettings
          );
        }
      );
      r.cornerRadius.set_value(
        this.#customWindowSettings[wmClass].borderRadius
      );
      r.cornerRadius.connect("value-changed", (adj) => {
        this.#customWindowSettings[wmClass].borderRadius = adj.get_value();
        setPref(
          "custom-rounded-corner-settings",
          this.#customWindowSettings
        );
      });
      r.cornerSmoothing.set_value(
        this.#customWindowSettings[wmClass].smoothing
      );
      r.cornerSmoothing.connect(
        "value-changed",
        (adj) => {
          this.#customWindowSettings[wmClass].smoothing = adj.get_value();
          setPref(
            "custom-rounded-corner-settings",
            this.#customWindowSettings
          );
        }
      );
      r.keepForMaximized.set_active(
        this.#customWindowSettings[wmClass].keepRoundedCorners.maximized
      );
      r.keepForMaximized.connect(
        "notify::active",
        (row2) => {
          this.#customWindowSettings[wmClass].keepRoundedCorners.maximized = row2.get_active();
          setPref(
            "custom-rounded-corner-settings",
            this.#customWindowSettings
          );
        }
      );
      r.keepForFullscreen.set_active(
        this.#customWindowSettings[wmClass].keepRoundedCorners.fullscreen
      );
      r.keepForFullscreen.connect(
        "notify::active",
        (row2) => {
          this.#customWindowSettings[wmClass].keepRoundedCorners.fullscreen = row2.get_active();
          setPref(
            "custom-rounded-corner-settings",
            this.#customWindowSettings
          );
        }
      );
      r.paddings.paddingTop = this.#customWindowSettings[wmClass].padding.top;
      r.paddings.connect(
        "notify::padding-top",
        (row2) => {
          this.#customWindowSettings[wmClass].padding.top = row2.paddingTop;
          setPref(
            "custom-rounded-corner-settings",
            this.#customWindowSettings
          );
        }
      );
      r.paddings.paddingBottom = this.#customWindowSettings[wmClass].padding.bottom;
      r.paddings.connect(
        "notify::padding-bottom",
        (row2) => {
          this.#customWindowSettings[wmClass].padding.bottom = row2.paddingBottom;
          setPref(
            "custom-rounded-corner-settings",
            this.#customWindowSettings
          );
        }
      );
      r.paddings.paddingStart = this.#customWindowSettings[wmClass].padding.left;
      r.paddings.connect(
        "notify::padding-start",
        (row2) => {
          this.#customWindowSettings[wmClass].padding.left = row2.paddingStart;
          setPref(
            "custom-rounded-corner-settings",
            this.#customWindowSettings
          );
        }
      );
      r.paddings.paddingEnd = this.#customWindowSettings[wmClass].padding.right;
      r.paddings.connect(
        "notify::padding-end",
        (row2) => {
          this.#customWindowSettings[wmClass].padding.right = row2.paddingEnd;
          setPref(
            "custom-rounded-corner-settings",
            this.#customWindowSettings
          );
        }
      );
    }
  }
);
export {
  CustomPage
};

import {
  Extension,
  gettext as _
} from "resource:///org/gnome/shell/extensions/extension.js";
import { PopupMenuItem } from "resource:///org/gnome/shell/ui/popupMenu.js";
function enableBackgroundMenuItem() {
  for (const background of global.windowGroup.firstChild.get_children()) {
    const menu = background._backgroundMenu;
    addItemToMenu(menu);
  }
}
function disableBackgroundMenuItem() {
  for (const background of global.windowGroup.firstChild.get_children()) {
    const menu = background._backgroundMenu;
    removeItemFromMenu(menu);
  }
}
function addItemToMenu(menu) {
  const rwcMenuItemName = _("Rounded Corners Settings...");
  for (const item of menu._getMenuItems()) {
    if (item instanceof PopupMenuItem && item.label.text === rwcMenuItemName) {
      return;
    }
  }
  menu.addAction(rwcMenuItemName, () => {
    const extension = Extension.lookupByURL(import.meta.url);
    extension.openPreferences();
  });
}
function removeItemFromMenu(menu) {
  const items = menu._getMenuItems();
  const rwcMenuItemName = _("Rounded Corners Settings...");
  for (const item of items) {
    if (item instanceof PopupMenuItem && item.label.text === rwcMenuItemName) {
      item.destroy();
      break;
    }
  }
}
export {
  disableBackgroundMenuItem,
  enableBackgroundMenuItem
};

function boxShadowCss(shadow, scale = 1) {
  return `box-shadow: ${shadow.horizontalOffset * scale}px
          ${shadow.verticalOffset * scale}px
          ${shadow.blurOffset * scale}px
          ${shadow.spreadRadius * scale}px
          rgba(0,0,0, ${shadow.opacity / 100})`;
}
export {
  boxShadowCss
};

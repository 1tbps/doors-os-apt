const ROUNDED_CORNERS_EFFECT = "Rounded Corners Effect";
const CLIP_SHADOW_EFFECT = "Clip Shadow Effect";
const SHADOW_PADDING = 80;
const APP_SHADOWS = {
  kitty: [11, 35, 11, 11]
};
const OVERVIEW_SHADOW_ACTOR = "Shadow Actor (Overview)";
export {
  APP_SHADOWS,
  CLIP_SHADOW_EFFECT,
  OVERVIEW_SHADOW_ACTOR,
  ROUNDED_CORNERS_EFFECT,
  SHADOW_PADDING
};

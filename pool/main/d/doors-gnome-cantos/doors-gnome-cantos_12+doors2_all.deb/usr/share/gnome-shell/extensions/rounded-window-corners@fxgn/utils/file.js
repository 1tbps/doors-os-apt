import GLib from "gi://GLib";
import Gio from "gi://Gio";
function readFile(path) {
  const file = Gio.File.new_for_path(path);
  const contents = file.load_contents(null)[1];
  const decoder = new TextDecoder("utf-8");
  return decoder.decode(contents);
}
function readRelativeFile(module, path) {
  const basedir = GLib.path_get_dirname(module);
  const fileUri = GLib.build_filenamev([basedir, path]);
  const filePath = GLib.filename_from_uri(fileUri)[0];
  return readFile(filePath ?? "");
}
function readShader(module, path) {
  const shader = readRelativeFile(module, path);
  let [declarations, code] = shader.split(/^.*?main\(\s?\)\s?/m);
  declarations = declarations.trim();
  code = code.trim().replace(/^[{}]/gm, "").trim();
  return [declarations, code];
}
export {
  readFile,
  readRelativeFile,
  readShader
};

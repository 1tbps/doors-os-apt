import { getPref } from "./settings.js";
function logDebug(...args) {
  if (getPref("debug-mode")) {
    console.log(`[Rounded Window Corners] ${args}`);
  }
}
function logError(...args) {
  console.error(`[Rounded Window Corners] ${args}`);
}
export {
  logDebug,
  logError
};

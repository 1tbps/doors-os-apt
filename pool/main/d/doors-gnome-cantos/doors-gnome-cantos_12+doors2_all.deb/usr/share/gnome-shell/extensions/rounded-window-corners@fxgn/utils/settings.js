import GLib from "gi://GLib";
import { logDebug } from "./log.js";
const Schema = {
  "settings-version": "u",
  blacklist: "as",
  "skip-libadwaita-app": "b",
  "skip-libhandy-app": "b",
  "border-width": "i",
  "global-rounded-corner-settings": "a{sv}",
  "custom-rounded-corner-settings": "a{sv}",
  "focused-shadow": "a{si}",
  "unfocused-shadow": "a{si}",
  "debug-mode": "b",
  "tweak-kitty-terminal": "b",
  "enable-preferences-entry": "b"
};
let prefs;
function initPrefs(gSettings) {
  resetOutdated(gSettings);
  prefs = gSettings;
}
function uninitPrefs() {
  prefs = null;
}
function getPref(key) {
  return prefs.get_value(key).recursiveUnpack();
}
function setPref(key, value) {
  logDebug(`Settings pref: ${key}, ${value}`);
  let variant;
  if (key === "global-rounded-corner-settings") {
    variant = packRoundedCornerSettings(value);
  } else if (key === "custom-rounded-corner-settings") {
    variant = packCustomRoundedCornerSettings(
      value
    );
  } else {
    variant = new GLib.Variant(Schema[key], value);
  }
  prefs.set_value(key, variant);
}
function bindPref(key, object, property, flags) {
  prefs.bind(key, object, property, flags);
}
function resetOutdated(prefs2) {
  const lastVersion = 7;
  const currentVersion = prefs2.get_user_value("settings-version")?.recursiveUnpack();
  if (!currentVersion || currentVersion < lastVersion) {
    if (prefs2.list_keys().includes("black-list")) {
      prefs2.reset("black-list");
    }
    prefs2.reset("global-rounded-corner-settings");
    prefs2.reset("custom-rounded-corner-settings");
    if (prefs2.list_keys().includes("border-color")) {
      prefs2.reset("border-color");
    }
    prefs2.reset("focused-shadow");
    prefs2.reset("unfocused-shadow");
    prefs2.set_uint("settings-version", lastVersion);
  }
}
function packRoundedCornerSettings(settings) {
  const padding = new GLib.Variant("a{su}", settings.padding);
  const keepRoundedCorners = new GLib.Variant(
    "a{sb}",
    settings.keepRoundedCorners
  );
  const borderRadius = GLib.Variant.new_uint32(settings.borderRadius);
  const smoothing = GLib.Variant.new_double(settings.smoothing);
  const borderColor = new GLib.Variant("(dddd)", settings.borderColor);
  const enabled = GLib.Variant.new_boolean(settings.enabled);
  const variantObject = {
    padding,
    keepRoundedCorners,
    borderRadius,
    smoothing,
    borderColor,
    enabled
  };
  return new GLib.Variant("a{sv}", variantObject);
}
function packCustomRoundedCornerSettings(settings) {
  const packedSettings = {};
  for (const [wmClass, windowSettings] of Object.entries(settings)) {
    packedSettings[wmClass] = packRoundedCornerSettings(windowSettings);
  }
  const variant = new GLib.Variant("a{sv}", packedSettings);
  return variant;
}
export {
  Schema,
  bindPref,
  getPref,
  initPrefs,
  prefs,
  setPref,
  uninitPrefs
};

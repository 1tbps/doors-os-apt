import Gio from "gi://Gio";
const connection = Gio.DBus.session;
const busName = "org.gnome.Shell";
const interfaceName = "org.gnome.Shell.Extensions.RoundedWindowCorners";
const objectPath = "/org/gnome/shell/extensions/RoundedWindowCorners";
function pick() {
  connection.call(
    busName,
    objectPath,
    interfaceName,
    "pick",
    null,
    null,
    Gio.DBusCallFlags.NO_AUTO_START,
    -1,
    null,
    null
  );
}
function onPicked(callback) {
  const id = connection.signal_subscribe(
    busName,
    interfaceName,
    "picked",
    objectPath,
    null,
    Gio.DBusSignalFlags.NONE,
    (_conn, _sender, _objectPath, _iface, _signal, params) => {
      const val = params.get_child_value(0);
      callback(val.get_string()[0]);
      connection.signal_unsubscribe(id);
    }
  );
}
export {
  onPicked,
  pick
};

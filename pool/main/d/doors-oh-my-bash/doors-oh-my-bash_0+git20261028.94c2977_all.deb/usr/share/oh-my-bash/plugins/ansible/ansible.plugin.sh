#! bash oh-my-bash.module
# Functions
function ansible-version(){
  ansible --version
}

function ansible-role-init(){
  if ! [ -z $1] ; then
    _omb_util_print "Ansible Role : $1 Creating...."
    ansible-galaxy init $1
    tree $1
  else
    _omb_util_print "Usage : ansible-role-init <role name>"
    _omb_util_print "Example : ansible-role-init role1"
  fi
}

# Aliases
alias a='ansible '
alias aconf='ansible-config '
alias acon='ansible-console '
alias aver='ansible-version'
alias arinit='ansible-role-init'
alias aplaybook='ansible-playbook '
alias ainv='ansible-inventory '
alias adoc='ansible-doc '
alias agal='ansible-galaxy '
alias apull='ansible-pull '
alias aval='ansible-vault'
